/** runtime-config foundation for project-repo-3464. */
export const projectRepo3464RuntimeConfig = Object.freeze({
  namespace: "project-repo-3464",
  profile: "multichain_app",
  variant: "runtime-config-v1-3",
  revision: 1483,
});

export type projectRepo3464RuntimeConfigConfig = typeof projectRepo3464RuntimeConfig;
