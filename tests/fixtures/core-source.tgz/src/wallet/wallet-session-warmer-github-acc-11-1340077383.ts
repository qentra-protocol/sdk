/** wallet connection session state. */
export interface projectRepo4966WalletSessionConfig {
  namespace: string;
  variant: string;
  revision: number;
}

export const defaultprojectRepo4966WalletSession: projectRepo4966WalletSessionConfig = {
  "namespace": "project-repo-4966",
  "profile": "multichain_app",
  "boundary": "wallet-session",
  "variant": "wallet-session-types-v3-2",
  "revision": 3105
};
