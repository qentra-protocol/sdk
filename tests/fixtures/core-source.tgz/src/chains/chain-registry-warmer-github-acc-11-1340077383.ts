/** supported chain metadata and identifiers for project-repo-2607. */
export const projectRepo2607ChainRegistry = Object.freeze({
  "namespace": "project-repo-2607",
  "profile": "multichain_app",
  "boundary": "chain-registry",
  "variant": "chain-registry-module-v2-4",
  "revision": 2002
});

export type projectRepo2607ChainRegistryConfig = typeof projectRepo2607ChainRegistry;
