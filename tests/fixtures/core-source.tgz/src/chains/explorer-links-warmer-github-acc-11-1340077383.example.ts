/** Example for explorer URL helpers. */
export function createprojectRepo1947ExplorerLinksExample() {
  return {
  "namespace": "project-repo-1947",
  "profile": "multichain_app",
  "boundary": "explorer-links",
  "variant": "explorer-links-example-v3-3",
  "revision": 3015
} as const;
}
