# Qentra Protocol

Quantum-verifiable randomness infrastructure for onchain applications.

Build with randomness ready for the quantum era. Qentra separates entropy origin, a checkable generation record, reproducible application mapping and delivery. This package implements request-record validation, deterministic helpers and persistence boundaries used by the SDK.

## Developer surfaces

- `src/index.ts`: request types, hex codec, SHA-256 digest, rejection sampler, mapping and repositories.
- `schemas/request-record.schema.json`: structural record format.
- `tests/core.test.ts`: bucket rejection, mapping constraints, replay and persistence isolation.
- `examples/verify-record.ts`: import and reproduce an allocation selection.
- [Module reference](docs/CORE.md) and [source boundary](docs/SOURCE.md).
- [SDK](https://github.com/nicpilsner/qentra-sdk) and [developer guides](https://github.com/nicpilsner/qentra-docs).

## Source development

Use Node 22 or newer. From this repository, run `npm install`, then `npm run check`. The check typechecks source/tests/examples, runs the core tests and import example, and builds declaration and ESM output. `npm pack` creates a local development archive after a build. Package version is `0.1.0-dev.0`; the package is private and installed from source.

The shared helpers map checked output deterministically for tournament winners, allocation applicants and agent selection. The native Solana client lives in the SDK companion and uses protocol-record schema 4; this core retains schema-1 browser-record validation and persistence for historical adapters. Record replay and source verification are distinct checks. See the SDK developer guide for quotes, native-SOL payment, proof verification and reopening.

The distributable core entrypoint is `src/index.ts`. Build/typecheck scope follows that entrypoint plus its tests/examples; unrelated repository source is not part of the package build. ESM and declarations contain only the supported package API.
