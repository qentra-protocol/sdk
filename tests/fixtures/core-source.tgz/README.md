# Qentra Protocol

Quantum-verifiable randomness infrastructure for onchain applications.

Build with randomness ready for the quantum era. Qentra separates entropy origin, a checkable generation record, reproducible application mapping and delivery. This package implements request-record validation, deterministic helpers and persistence boundaries used by the SDK.

## Developer surfaces

- `src/index.ts`: request types, hex codec, SHA-256 digest, rejection sampler, mapping and repositories.
- `schemas/request-record.schema.json`: structural record format.
- `tests/core.test.ts`: bucket rejection, mapping constraints, replay and persistence isolation.
- `examples/verify-record.ts`: import and reproduce an allocation selection.
- [Module reference](docs/CORE.md) and [source boundary](docs/SOURCE.md).
- [SDK](https://github.com/nicpilsner/qentra-sdk) and [developer guides](https://github.com/nicpilsner/qentra-docs).

## Source development

Use Node 22 or newer. From this repository, run `npm install`, then `npm run check`. The check typechecks source/tests/examples, runs the core tests and import example, and builds declaration and ESM output. `npm pack` creates a local development archive after a build. Package version is `0.1.0-dev.0`; the package is private and installed from source.

The initial adapter uses browser Web Crypto with source mode `browser-cryptographic`. Record import reproduces application mapping; source verification and delivery remain separate fields. See the source boundary for integration details.
